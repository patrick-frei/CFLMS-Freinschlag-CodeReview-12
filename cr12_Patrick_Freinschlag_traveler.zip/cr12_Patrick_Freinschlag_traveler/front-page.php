<!-- THIS IS THE STATIC LANDING PAGE-->
<?php get_header(); ?>
<div class="container">
  <h1 class="display-4 text-center mb-2 mb-md-5">This is my static landing page for cr12</h1>
  <img src="https://images.pexels.com/photos/41162/moon-landing-apollo-11-nasa-buzz-aldrin-41162.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260" class="w-100">
</div>
<?php get_footer(); ?>