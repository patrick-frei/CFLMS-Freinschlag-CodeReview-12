<div id="comments" class="comments-area">

  <?php if (have_comments()) : ?>
    <h2 class="comments-title">
      <?php
      printf(
        _nx('One Comment', '%1$s Comments', get_comments_number(), 'comments title', 'twentythirteen'),
        number_format_i18n(get_comments_number()),
        '<span>' . get_the_title() . '</span>'
      );
      ?>
    </h2>

    <ol class="py-md-5 my-md-5 px-sm-0 mx-sm-0">
      <?php
      require_once('class-wp-bootstrap-comment-walker.php');

      wp_list_comments(array(
        'style'         => 'ol',
        'max_depth'     => 4,
        'short_ping'    => true,
        'avatar_size'   => '50',
        'walker'        => new Bootstrap_Comment_Walker(),
      ));
      ?>
    </ol>

    <?php
    // Are there comments to navigate through?
    if (get_comment_pages_count() > 1 && get_option('page_comments')) :
    ?>
      <nav class="navigation comment-navigation" role="navigation">
        <h1 class="screen-reader-text section-heading">1<?php _e('Comment navigation', 'twentythirteen'); ?></h1>
        <div class="nav-previous"><?php previous_comments_link(__('&amp;larr; Older Comments', 'twentythirteen')); ?></div>
        <div class="nav-next"><?php next_comments_link(__('Newer Comments &amp;rarr;', 'twentythirteen')); ?></div>
      </nav><!-- .comment-navigation -->
    <?php endif; // Check for comment navigation 
    ?>

    <?php if (!comments_open() && get_comments_number()) : ?>
      <p class="text-muted"><?php _e('Comments are closed.', 'twentythirteen'); ?></p>
    <?php endif; ?>

  <?php endif; ?>
  <?php
  $fields = array(
    'author' =>
    '<p class="comment-form-author">
    <div class="form-group"><label for="author">' . __('Name', 'domainreference') . '</label> ' .
      ($req ? '<span class="required">*</span>' : '') .
      '<input id="author" class="form-control" name="author" type="text" value="' . esc_attr($commenter['comment_author']) .
      '" ' . $aria_req . ' /></div>
  </p>',
    'email' =>
    '<p class="comment-form-email">
    <div class="form-group"><label for="email">' . __('Email', 'domainreference') . '</label> ' .
      ($req ? '<span class="required">*</span>' : '') .
      '<input id="email" name="email" class="form-control" type="text" value="' . esc_attr($commenter['comment_author_email']) .
      '" ' . $aria_req . ' /></div>
  </p>',
    'url' =>
    '<p class="comment-form-url">
    <div class="form-group"><label for="url">' . __('Website', 'domainreference') . '</label>' .
      '<input id="url" name="url" class="form-control" type="text" value="' . esc_attr($commenter['comment_author_url']) .
      '" />
  </p>',
  );
  $comments_args = array(
    'title_reply' => 'Wanna leave a comment?',
    'fields' => apply_filters('comment_form_default_fields', $fields),
    'comment_field' => '<p class="comment-form-comment"><div class="form-group"><label for="comment">' . _x('Comment', 'noun') . ':</label><textarea id="comment" name="comment" class="form-control" rows="8" aria-required="true">' . '</textarea></div></p>',
    'comment_notes_after' => ' '
  );
  ?>
  <?php comment_form($comments_args); ?>

</div>