<footer class="py-4 bg-dark text-light mt-2 mt-md-5">
  <div class="container text-center"><small>© 2020 Freinschlag | All Rights Reserved</small></div>
</footer>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<?php wp_footer() ?>
</body>
</html>