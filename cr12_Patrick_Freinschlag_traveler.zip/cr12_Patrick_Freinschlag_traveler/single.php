<?php get_header(); ?>
<div class="container">
  <?php if (have_posts()) : ?>
    <?php while (have_posts()) : the_post(); ?>
      <div>
        <div class="d-flex justify-content-end">
          <small class="text-muted"><?php the_time('F j, Y g:i a'); ?> by <?php the_author(''); ?></small>
        </div>
        <h1 class="display-4 text-center my-1 my-md-3"><?php the_title(); ?></h1>
        <p class="my-1 my-md-3"><?php the_content(); ?></p>
      </div>
      <?php comments_template(); ?>
    <?php endwhile; ?>
  <?php else : ?>
    <?php __('No Posts Found'); ?>
  <?php endif; ?>
</div>
<?php get_footer(); ?>