<?php get_header(); ?>
<div class="container">
  <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4">
    <?php if (have_posts()) : ?>
      <?php while (have_posts()) : the_post(); ?>
        <div class="col text-center">
          <h2 class="mb-1 mb-md-3"><?php the_title(); ?></h2>
          <?php if (has_post_thumbnail()) {
            the_post_thumbnail('full', array('class' => 'img-fluid'));
          } ?>
          <p><?php the_excerpt(); ?></p>
          <a href="<?php the_permalink(); ?>" class="btn btn-outline-secondary mb-1 mb-md-3">Read more</a>
          <p class="text-muted m-1"><?php the_time('F j, Y g:i a'); ?></p>
          <p class="text-muted m-1"><?php the_author('F j, Y g:i a'); ?></p>
        </div>
      <?php endwhile; ?>
    <?php else : ?>
      <?php __('No Posts Found'); ?>
    <?php endif; ?>
  </div>
</div>
<?php get_footer(); ?>